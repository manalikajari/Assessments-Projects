//Manali kajari Test code 11/7/22
//import required classes and packages for JDBC, UI and execeptions
package net.codejava.jdbc;
import java.sql.*;
import javax.swing.*;  
import java.awt.*;  
import java.awt.event.*;  
import java.lang.Exception;  
  
 
class Manali_Login_Form_test extends JFrame implements ActionListener 

{   
    boolean login = false; //boolean value for login success or failure

	private static final long serialVersionUID = 1L;
	// initialize UI elements
    JButton b1, b2;  
    JPanel uiPanel;  
    JTextField  textField1, textField2; 
    JLabel usernameLabel, passwordLabel, errorLabel, registerLabel;  

    
      
    //calling and initializing in constructor  
    Manali_Login_Form_test() 		 
    {     
        //create label for username   
        usernameLabel = new JLabel();  
        usernameLabel.setText("Username");      //set label value for textField1  
          
        //create text field to get username from the user  
        textField1 = new JTextField(15);    //set length of the text  
  
        //create label for password  
        passwordLabel = new JLabel();  
        passwordLabel.setText("Password");      //set label value for textField2  
          
        //create text field to get password from the user  
        textField2 = new JPasswordField(15);    //set length for the password  
         
        //create text field for error message
        errorLabel = new JLabel();
        errorLabel.setText("Please enter valid username and password");  
        errorLabel.setVisible(false);       //Label will be invisible in the beginning 
        
        registerLabel = new JLabel();
        registerLabel.setText("You have successfully registered");  
        registerLabel.setVisible(false);        //Label will be invisible in the beginning 
        
        
        b1 = new JButton("SUBMIT"); //set label to submit button  
        b2 = new JButton("REGISTER"); //set label to register button  

        //create panel to put form elements  
        uiPanel = new JPanel(new GridLayout(4, 1));  
        uiPanel.add(usernameLabel);    //set username label to panel  
        uiPanel.add(textField1);   //set text field to panel  
        uiPanel.add(passwordLabel);    //set password label to panel  
        uiPanel.add(textField2);   //set text field to panel  
        uiPanel.add(b1);           //set submit button to panel  
        uiPanel.add(b2);            //set register button to panel
        uiPanel.add(errorLabel);   //set text field to panel  
        uiPanel.add(registerLabel);   //set text field to panel  

        //set border to panel   
        add(uiPanel, BorderLayout.CENTER);  
          
        //perform action on button click   
        b1.addActionListener(this);     //add action listener to submit button 
        b2.addActionListener(this);     //add action listener to register button 
        setTitle("LOGIN FORM TEST");         
    }  
      
    public void actionPerformed(ActionEvent ae)   //action listeners    
    {           
    	 
        String userValue = textField1.getText();        //get user entered username   
        String passValue = textField2.getText();        //get user entered password  
        
        	String databaseURL = "jdbc:ucanaccess://C://Users//Manali//Downloads//Manali_Test_DB.accdb"; //path to MSACCESS database
         	 if(ae.getSource() == b1) { //check if user clicked submit button

      try (Connection connection = DriverManager.getConnection(databaseURL)) 

        	{

    	 ResultSet  resultSet = null; 
     	  String sql = "SELECT * FROM Authentication_Test WHERE Username = ? and Password = ? ";
        	   PreparedStatement preparedStatement = connection.prepareStatement(sql);
        	   preparedStatement.setString(1, userValue);
        	   preparedStatement.setString(2, passValue);
        	   resultSet = preparedStatement.executeQuery();
        	   login = resultSet.next();

        	   
        	   
        	} catch (SQLException ex) {
        	    ex.printStackTrace();
        	}
      if(login) { //if entered credentials are correct
            //create instance of the NewPage  
        	HomePage page = new HomePage();  
        	errorLabel.setVisible(false); 
        	 registerLabel.setVisible(false);

            //make page visible to the user  
            page.setVisible(true);  
              
            //create a welcome label and set it to the new page  
            JLabel wel_label = new JLabel("Welcome: "+userValue);  
            page.getContentPane().add(wel_label);  
      }else { // if entered credentials are incorrect
    	  errorLabel.setVisible(true);
    	  System.out.println("Please enter valid username and password");  
      }
       
    }
        	 else { //if user clicked register button
        		 
        		 
        		 try (Connection connection = DriverManager.getConnection(databaseURL)) 

             	{
        			  errorLabel.setVisible(false);
              	  String sql = "INSERT INTO Authentication_Test (Username, Password) VALUES (?, ?)";
              	   PreparedStatement preparedStatement = connection.prepareStatement(sql);
             	   preparedStatement.setString(1, userValue);
             	   preparedStatement.setString(2, passValue);
             	  preparedStatement.executeUpdate(); 
             	 registerLabel.setVisible(true); // you have successfully registered

             	   
             	} catch (SQLException ex) {
             	    ex.printStackTrace();
             	}
        		 
        		 
        	 }    	 
    
    }  
}  
// main class  
class Manali_LoginForm_Test_demo 
{  
     public static void main(String arg[])  
    {  
        try  
        {  
         	Manali_Login_Form_test form = new Manali_Login_Form_test();  
            form.setSize(1200,500); 
            form.setVisible(true);     
        }  
        catch(Exception e)  
        {     
             JOptionPane.showMessageDialog(null, e.getMessage());  
        }  
    }  
}  