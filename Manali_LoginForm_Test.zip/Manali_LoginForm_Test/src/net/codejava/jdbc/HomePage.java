package net.codejava.jdbc;
import javax.swing.*;  
import java.awt.*;  
  
 class HomePage extends JFrame  
{  
    //constructor  
	HomePage()  
    {  
        setDefaultCloseOperation(javax.swing.  
        WindowConstants.DISPOSE_ON_CLOSE);  
        setTitle("Welcome to X-logia family");  
        setSize(400, 200);  
    }  
}  